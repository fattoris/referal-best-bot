# Referal_best_bot

## Как запустить:

1. Установите Python 3.9+
2. Установите зависимости:
   pip install -r requirements.txt
3. Установите переменную окружения BOT_TOKEN (токен от BotFather)
4. Запустите:
   python bot.py

## Команды:
/start — получить реф. ссылку
/referrals — статистика
/help — правила
